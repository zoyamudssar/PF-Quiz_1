/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int N, i;
    int intensiveCount = 0;
    float fee, totalIncome ;
    
    printf("Enter a number of students :");
    scanf("%d", &N);
    for(i = 1; i <= N; i++)
    { 
        printf("Enter tution fee for student %d =", i);
        scanf("%f", &fee);
        totalIncome += fee;
        if (fee > 12000)
    { 
        printf("Intensive Course\n");
        intensiveCount++;
    }
}
    printf("\nTotal Income = %f\n", totalIncome);
    printf("Intensive Course Students = %d\n", intensiveCount);
    return 0;
}